/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     04/03/2020 13:24:00                          */
/*==============================================================*/


drop table if exists ACTOR;

drop table if exists DIRECTOR;

drop table if exists FUNCION;

drop table if exists OPINION;

drop table if exists PELICULA;

drop table if exists SALA;

drop table if exists TIENE5;

drop table if exists TIENE6;

/*==============================================================*/
/* Table: ACTOR                                                 */
/*==============================================================*/
create table ACTOR
(
   NOMBRE_A             char(30) not null,
   NACIONALIDAD_A       char(10),
   CANTIDAD_PELICULAS_A int,
   primary key (NOMBRE_A)
);

/*==============================================================*/
/* Table: DIRECTOR                                              */
/*==============================================================*/
create table DIRECTOR
(
   NOMBRE_D             char(30) not null,
   NACIONALIDAD_D       char(10),
   CANTIDAD_PELICULAS_D int,
   primary key (NOMBRE_D)
);

/*==============================================================*/
/* Table: FUNCION                                               */
/*==============================================================*/
create table FUNCION
(
   SALA                 int not null,
   NUMERO_SALA          int not null,
   ID_PELICULA          int not null,
   HORA_INICIO          time,
   DURACCION_F          time,
   DESCRIPCION_PROMOCION char(50),
   DESCUENTO_PROMOCION  int,
   primary key (SALA)
);

/*==============================================================*/
/* Table: OPINION                                               */
/*==============================================================*/
create table OPINION
(
   NUMERO_OPINION       int not null,
   ID_PELICULA          int not null,
   REDACTOR             char(30),
   EDAD                 int,
   CALIFICACION_O       int,
   FECHA                date,
   primary key (NUMERO_OPINION)
);

/*==============================================================*/
/* Table: PELICULA                                              */
/*==============================================================*/
create table PELICULA
(
   ID_PELICULA          int not null,
   FECHA_PRODUCCION     date,
   FECHA_ESTRENO        date,
   DURACION             time,
   SUBTITULO_ESPANOL    bool,
   CALIFICACION_P       int,
   GENERO               char(10),
   PAIS_ORIGEN          char(30),
   TITULO_ORIGINAL      char(30),
   TITULO_DISTRIBUCION  char(30),
   IDIOMA_ORIGINAL      char(30),
   RESUMEN              char(30),
   URL                  char(50),
   primary key (ID_PELICULA)
);

/*==============================================================*/
/* Table: SALA                                                  */
/*==============================================================*/
create table SALA
(
   NUMERO_SALA          int not null,
   NOMBRE_S             char(30),
   DIRECCION_S          char(30),
   TELEFONO_S           int,
   primary key (NUMERO_SALA)
);

/*==============================================================*/
/* Table: TIENE5                                                */
/*==============================================================*/
create table TIENE5
(
   NOMBRE_A             char(30) not null,
   ID_PELICULA          int not null,
   primary key (NOMBRE_A, ID_PELICULA)
);

/*==============================================================*/
/* Table: TIENE6                                                */
/*==============================================================*/
create table TIENE6
(
   NOMBRE_D             char(30) not null,
   ID_PELICULA          int not null,
   primary key (NOMBRE_D, ID_PELICULA)
);

alter table FUNCION add constraint FK_EXHIBE foreign key (NUMERO_SALA)
      references SALA (NUMERO_SALA) on delete restrict on update restrict;

alter table FUNCION add constraint FK_TIENE3 foreign key (ID_PELICULA)
      references PELICULA (ID_PELICULA) on delete restrict on update restrict;

alter table OPINION add constraint FK_TIENE foreign key (ID_PELICULA)
      references PELICULA (ID_PELICULA) on delete restrict on update restrict;

alter table TIENE5 add constraint FK_TIENE5 foreign key (NOMBRE_A)
      references ACTOR (NOMBRE_A) on delete restrict on update restrict;

alter table TIENE5 add constraint FK_TIENE8 foreign key (ID_PELICULA)
      references PELICULA (ID_PELICULA) on delete restrict on update restrict;

alter table TIENE6 add constraint FK_TIENE6 foreign key (NOMBRE_D)
      references DIRECTOR (NOMBRE_D) on delete restrict on update restrict;

alter table TIENE6 add constraint FK_TIENE7 foreign key (ID_PELICULA)
      references PELICULA (ID_PELICULA) on delete restrict on update restrict;

