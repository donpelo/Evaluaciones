package Prueba;

public class Lavadora extends Electrodomestico{
	  
	private int carga;
   
    private final static int cargapordefecto=5;
  
    
    public Lavadora(){
        this(preciobasepordefecto, pesopordefecto, consumoenergeticopordefecto, colorpordefecto, cargapordefecto);
    }
  
    public Lavadora(double precioBase, double peso){
        this(precioBase, peso, consumoenergeticopordefecto, colorpordefecto, cargapordefecto);
    }
  
    
    public Lavadora(double precioBase, double peso, char consumoEnergetico, String color, int carga){
        super(precioBase,peso, consumoEnergetico,color);
        this.carga=carga;
    }

    public int getCarga() {
        return carga;
    }
  

    public double precioFinal(){
     
        double agregado=super.precioFinal();
  
       
        if (carga>30){
            agregado+=40000;
        }
  
        return agregado;
    }
  
 
 
  
}
