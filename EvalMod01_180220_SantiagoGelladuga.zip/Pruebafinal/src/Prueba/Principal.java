package Prueba;


public class Principal {

	public static void main(String[] args) {
		   
		
        
        Electrodomestico todosloselectrodomesticos[] = new Electrodomestico[10];
   
        
        double Sumadetodoslostelevisores=0;
        double Sumadetodaslaslavadoras=0;
        double Sumadetodosloselectrodomesticos=0;
        
        
       
        todosloselectrodomesticos[0]=new Electrodomestico(150, 80, 'A', "Negro");
        todosloselectrodomesticos[1]=new Lavadora(300, 40, 'C', "blanco", 40);
        todosloselectrodomesticos[2]=new Television(500, 80, 'E', "negro", 42, true);
        todosloselectrodomesticos[3]=new Television(180, 70, 'B', "Gris", 35, true);
        todosloselectrodomesticos[4]=new Electrodomestico(750, 15, 'D', "rojo");
        todosloselectrodomesticos[5]=new Lavadora(190, 60, 'E', "Rojo", 50);
        todosloselectrodomesticos[6]=new Television(487, 70, 'F', "Azul", 42, true);
        todosloselectrodomesticos[7]=new Lavadora(360, 40, 'A', "Negro", 25);
        todosloselectrodomesticos[8]=new Electrodomestico(450, 20, 'C', "Gris");
        todosloselectrodomesticos[9]=new Electrodomestico(30, 30, 'F',"Rojo");
   
        

   
        
        
        for(int i=0;i<todosloselectrodomesticos.length;i++){
           
        	 if(todosloselectrodomesticos[i] instanceof Television){
                 Sumadetodoslostelevisores+=todosloselectrodomesticos[i].precioFinal();
             }
        	 if(todosloselectrodomesticos[i] instanceof Lavadora){
                 Sumadetodaslaslavadoras+=todosloselectrodomesticos[i].precioFinal();
             }
   
            if(todosloselectrodomesticos[i] instanceof Electrodomestico){
                Sumadetodosloselectrodomesticos+=todosloselectrodomesticos[i].precioFinal();
            }
           
           
        }
        
        System.out.println("*****************************************************************************************");
        System.out.println("*************************Informacion Solicitada******************************************");
        System.out.println("*****************************************************************************************");
        System.out.println("*****************El total de la suma de todas las TV�s es de "+Sumadetodoslostelevisores+"**********************");
        System.out.println("*****************************************************************************************");
        System.out.println("*****************El total de la suma de todas las Lavadoras es de "+Sumadetodaslaslavadoras+"*****************");
        System.out.println("*****************************************************************************************");
        System.out.println("*************El total de la suma de todas los Electrodomesticos es de "+Sumadetodosloselectrodomesticos+"*************");
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        
        
   
    }
	
}
