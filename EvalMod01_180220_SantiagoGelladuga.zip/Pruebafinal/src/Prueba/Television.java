package Prueba;

public class Television extends Electrodomestico{
	  
	
	   private int resolucion;
	   private boolean TDT;
    
        private final static int resolucionpordefecto=20;
  

    public Television(){
        this(preciobasepordefecto, pesopordefecto, consumoenergeticopordefecto, colorpordefecto, resolucionpordefecto, false);
    }
  
  
    public Television(double precioBase, double peso){
        this(precioBase, peso, consumoenergeticopordefecto,colorpordefecto, resolucionpordefecto, false);
    }
  
  
    public Television(double precioBase, double peso, char consumoEnergetico, String color, int resolucion, boolean sintonizadorTDT){

        super(precioBase, peso, consumoEnergetico, color);
        this.resolucion=resolucion;
        this.TDT=sintonizadorTDT;
    }
    
    public double precioFinal(){
     
        double plus=super.precioFinal();
  
      
        if (resolucion>40){
            plus+=precioBase*0.3;
        }
        if (TDT){
            plus+=50;
        }
  
        return plus;
    }
  
}
