package Prueba;

public class Electrodomestico {
	   
    
    double precioBase;
    String color;
    char Tipoconsumo;
    double peso;
   
	
    protected final static String colorpordefecto="blanco";
    protected final static char consumoenergeticopordefecto='F';
    protected final static double preciobasepordefecto=100;
    protected final static double pesopordefecto=5;
    

  
    public Electrodomestico(){

        this(preciobasepordefecto, pesopordefecto, consumoenergeticopordefecto, colorpordefecto);
    }
   
    public Electrodomestico(double precioBase, double peso){
        this(precioBase, peso, consumoenergeticopordefecto, colorpordefecto);
    }
    
    
    public Electrodomestico(double precioBase, double peso, char consumoEnergetico, String color){
        this.precioBase=precioBase;
        this.peso=peso;
        comprobaciondeconsumoenergetico(consumoEnergetico);
        comprobaciondeColor(color);
    }
    
    private void comprobaciondeColor(String color){
    	   
        
        String colorelectrodomestico[]={"blanco", "gris","azul","Rojo", "Negro" };
        boolean busquedacolor=false;
  
        for(int i=0;i<colorelectrodomestico.length && !busquedacolor;i++){
              
            if(colorelectrodomestico[i].equals(color)){
                busquedacolor=true;
            }
              
        }
          
        if(busquedacolor){
            this.color=color;
        }else{
            this.color=colorpordefecto;
        }
          
          
    }
    
    public void comprobaciondeconsumoenergetico(char consumoEnergetico){
        
        if(consumoEnergetico>=65 && consumoEnergetico<=70){
            this.Tipoconsumo=consumoEnergetico;
        }else{
            this.Tipoconsumo=consumoenergeticopordefecto;
        }
          
    }
    
    public double getPrecioBase() {
        return precioBase;
    }

    public String getColor() {
        return color;
    }
   
    public char getConsumoEnergetico() {
        return Tipoconsumo;
    }
 
    public double getPeso() {
        return peso;
    }

    public double precioFinal(){
        double agregado=0;
        switch(Tipoconsumo){
            case 'A':
                agregado+=85000;
                break;
            case 'B':
                agregado+=70000;
                break;
            case 'C':
                agregado+=50000;
                break;
            case 'D':
                agregado+=40000;
                break;
            case 'E':
                agregado+=25000;
                break;
            case 'F':
                agregado+=8500;
                break;
        }
   
        if(peso>=0 && peso<19){
            agregado+=8500;
        }else if(peso>=20 && peso<49){
            agregado+=40000;
        }else if(peso>=50 && peso<=79){
            agregado+=70000;
        }else if(peso>=80){
            agregado+=85000;
        }
   
        return precioBase+agregado;
    }
   
} 
  