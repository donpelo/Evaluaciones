package Cajero;

public class cliente extends cuenta {
	
	
	String nombrecliente[][] = new String[10][3];
	String apellidocliente[][]= new String[10][3];;
	int rutcliente[][] = new int[10][3];
	
	
	
	public cliente(String[][] Tipocuenta, int[][] Numcuenta, String[][] Nombre, String[][] Apellido, int[][] Rut, double[][] Saldo, int [][] Clave) {
		
		
		super(Tipocuenta, Numcuenta, Nombre, Apellido, Rut, Saldo, Clave);
		
		
		this.nombrecliente = Nombre;
		this.apellidocliente = Apellido;
		this.rutcliente = Rut;
	}
	
	
	
	
}
