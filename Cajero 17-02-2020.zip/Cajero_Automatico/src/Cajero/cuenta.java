package Cajero;

import java.util.Scanner;

public class cuenta {
	
	private static Scanner entrada;
	
	String tipocuenta[][] = new String [10][7];
	int numcuenta[][] = new int [10][7];
	String nombrecliente[][] = new String [10][7];;
	String apellidocliente[][] = new String [10][7];
	int rutcliente[][] = new int [10][7];
    double saldo[][] = new double [10][7];
    int clave[][] = new int[10][7];
    String movimientos[][] = new String[5][5];
    double saldodeingreso;
    double saldoretiro;
	int respuestatipo=0;
	boolean validaradmin;
	boolean validarutcliente;
	int validacliente;
	int clavecliente;
	int clavecambio;
	int nuevaclave;

	private String rut;
	
	//informacion de las primeras 5 cuentas con asignacion a los parametros
	{
	this.tipocuenta[0][0]="Cuenta corriente";
	this.numcuenta [0][1]=0001;
	this.nombrecliente[0][2]="Luis";
	this.apellidocliente[0][3]="Pacheco";
	this.rutcliente[0][4]=168457893;
	this.saldo[0][5]=300000;
	this.clave[0][6]=1234;
	
	this.tipocuenta[1][0]="Cuenta ahorro";
	this.numcuenta [1][1]=0002;
	this.nombrecliente[1][2]="jose";
	this.apellidocliente[1][3]="ramirez";
	this.rutcliente[1][4]=78954248;
	this.saldo[1][5]=150000;
	this.clave[1][6]=3456;
	
	this.tipocuenta[2][0]="Cuenta vista";
	this.numcuenta [2][1]=0003;
	this.nombrecliente[2][2]="Fernando";
	this.apellidocliente[2][3]="Tapia";
	this.rutcliente[2][4]=206849876;
	this.saldo[2][5]=789550;
	this.clave[2][6]=4567;
	
	this.tipocuenta[3][0]="Cuenta Corriente";
	this.numcuenta [3][1]=0004;
	this.nombrecliente[3][2]="Cristobal";
	this.apellidocliente[3][3]="parga";
	this.rutcliente[3][4]=198465231;
	this.saldo[3][5]=325000;
	this.clave[3][6]=9876;
	
	this.tipocuenta[4][0]="Cuenta Vista";
	this.numcuenta [4][1]=0005;
	this.nombrecliente[4][2]="Santiago";
	this.apellidocliente[4][3]="Gelladuga";
	this.rutcliente[4][4]=176154470;
	this.saldo[4][5]=400000;
	this.clave[4][6]=3886;
	
}
	
	
    public cuenta(String Tipocuenta[][], int Numcuenta[][],String Nombre[][],String Apellido[][], int Rut[][], double Saldo[][], int Clave[][]) {
		
		super();
		this.tipocuenta = Tipocuenta;
		this.numcuenta = Numcuenta;
		this.nombrecliente = Nombre;
		this.apellidocliente = Apellido;
		this.rutcliente = Rut;
		this.saldo = Saldo;
		this.clave = Clave;
		
	}
		
	public cuenta() {
		
		entrada= new Scanner(System.in);
		
	}
	
	//metodo para crear cuentas bancarias
	public void crearcuenta(String Tipocuenta) {
		
 if(this.tipocuenta[5][0]!=null && this.tipocuenta[6][0]!=null && this.tipocuenta[7][0]!=null && this.tipocuenta[8][0]!=null && this.tipocuenta[9][0]!=null) {
			 
			 System.out.println("Formulario lleno. No se pueden ingresar mas personas");
			 menu2();
			
		 }
		
      if(this.tipocuenta[5][0]!=null && this.tipocuenta[6][0]!=null && this.tipocuenta[7][0]!=null && this.tipocuenta[8][0]!=null && this.nombrecliente[9][2]==null) {
			
			sabertipocuenta(Tipocuenta);
	        	
			    this.tipocuenta[9][0]=this.tipocuenta[9][0];
		     	  
		     	  System.out.println("Ingrese numero de cuenta");
		   		
		   		this.numcuenta[9][1] = entrada.nextInt();
		   		
		   		System.out.println("Ingrese nombre del cliente");
		   		
		   		this.nombrecliente[9][2]= entrada.next();
		   		
		   		System.out.println("Ingrese Apellido del cliente");
		   		
		   		this.apellidocliente[9][3]= entrada.next();
		   		
		   		System.out.println("Ingrese Rut del cliente");
		   		
		   		this.rutcliente[9][4] = entrada.nextInt();
		   		
		        System.out.println("Ingrese su primer saldo");
		   		
		        this.saldo[9][5] = entrada.nextDouble();
		           
		        System.out.println("Ingrese la clave para esta cuenta");
			   		
		        this.clave[9][6] = entrada.nextInt();
		   		
		   		System.out.println("Cuenta Creada Exitosamente");
				
		   		menu2();
		   		
			}
		
         if(this.tipocuenta[5][0]!=null && this.tipocuenta[6][0]!=null && this.tipocuenta[7][0]!=null && this.tipocuenta[8][0]==null && this.nombrecliente[9][2]==null) {
			
			sabertipocuenta(Tipocuenta);
	        	
			    this.tipocuenta[8][0]=this.tipocuenta[9][0];
		     	  
		     	  System.out.println("Ingrese numero de cuenta");
		   		
		   		this.numcuenta[8][1] = entrada.nextInt();
		   		
		   		System.out.println("Ingrese nombre del cliente");
		   		
		   		this.nombrecliente[8][2]= entrada.next();
		   		
		   		System.out.println("Ingrese Apellido del cliente");
		   		
		   		this.apellidocliente[8][3]= entrada.next();
		   		
		   		System.out.println("Ingrese Rut del cliente");
		   		
		   		this.rutcliente[8][4] = entrada.nextInt();
		   		
		           System.out.println("Ingrese su primer saldo");
		   		
		           this.saldo[8][5] = entrada.nextDouble();
		           
		           System.out.println("Ingrese la clave para esta cuenta");
			   		
		           this.clave[8][6] = entrada.nextInt();
		   		
		   		System.out.println("Cuenta Creada Exitosamente");
				
		   		menu2();
		   		
			}
		
    if(this.tipocuenta[5][0]!=null && this.tipocuenta[6][0]!=null && this.tipocuenta[7][0]==null && this.tipocuenta[8][0]==null && this.nombrecliente[9][2]==null) {
			
			sabertipocuenta(Tipocuenta);
	        	
			    this.tipocuenta[7][0]=this.tipocuenta[9][0];
		     	  
		     	  System.out.println("Ingrese numero de cuenta");
		   		
		   		this.numcuenta[7][1] = entrada.nextInt();
		   		
		   		System.out.println("Ingrese nombre del cliente");
		   		
		   		this.nombrecliente[7][2]= entrada.next();
		   		
		   		System.out.println("Ingrese Apellido del cliente");
		   		
		   		this.apellidocliente[7][3]= entrada.next();
		   		
		   		System.out.println("Ingrese Rut del cliente");
		   		
		   		this.rutcliente[7][4] = entrada.nextInt();
		   		
		           System.out.println("Ingrese su primer saldo");
		   		
		           this.saldo[7][5] = entrada.nextDouble();
		           
		           System.out.println("Ingrese la clave para esta cuenta");
			   		
		           this.clave[7][6] = entrada.nextInt();
		   		
		   		System.out.println("Cuenta Creada Exitosamente");
				
		   		menu2();
		   		
			}
		
		
         if(this.tipocuenta[5][0]!=null && this.tipocuenta[6][0]==null && this.tipocuenta[7][0]==null && this.tipocuenta[8][0]==null && this.nombrecliente[9][2]==null) {
			
			sabertipocuenta(Tipocuenta);
	        	
			    this.tipocuenta[6][0]=this.tipocuenta[9][0];
		     	  
		     	  System.out.println("Ingrese numero de cuenta");
		   		
		   		this.numcuenta[6][1] = entrada.nextInt();
		   		
		   		System.out.println("Ingrese nombre del cliente");
		   		
		   		this.nombrecliente[6][2]= entrada.next();
		   		
		   		System.out.println("Ingrese Apellido del cliente");
		   		
		   		this.apellidocliente[6][3]= entrada.next();
		   		
		   		System.out.println("Ingrese Rut del cliente");
		   		
		   		this.rutcliente[6][4] = entrada.nextInt();
		   		
		           System.out.println("Ingrese su primer saldo");
		   		
		           this.saldo[6][5] = entrada.nextDouble();
		           
		           System.out.println("Ingrese la clave para esta cuenta");
			   		
		           this.clave[6][6] = entrada.nextInt();
		   		
		   		System.out.println("Cuenta Creada Exitosamente");
				
		   		menu2();
		   		
			}
		
        
         
		
        	sabertipocuenta(Tipocuenta);
		
		
	
		this.tipocuenta[5][0]=this.tipocuenta[9][0];
		
			
		System.out.println("Ingrese numero de cuenta");
		
		this.numcuenta[5][1] = entrada.nextInt();
		
		System.out.println("Ingrese nombre del cliente");
		
		this.nombrecliente[5][2]= entrada.next();
		
		System.out.println("Ingrese Apellido del cliente");
		
		this.apellidocliente[5][3]= entrada.next();
		
		System.out.println("Ingrese Rut del cliente");
		
		this.rutcliente[5][4] = entrada.nextInt();
		
        System.out.println("Ingrese su primer saldo");
		
        this.saldo[5][5] = entrada.nextDouble();
        
        System.out.println("Ingrese la clave para esta cuenta");
   		
        this.clave[5][6] = entrada.nextInt();
		
		System.out.println("Cuenta Creada Exitosamente");
		
		
		menu2();
		
         
	}
	
	//metodo para designar el tipo de cuenta por medio de un switch
	public void sabertipocuenta(String Tipocuenta) {
		
		
		
		System.out.println("Seleccion tipo de cuenta");
		System.out.println("1.-  Cuenta corriente   ");
		System.out.println("2.-  Cuenta Ahorro      ");
		System.out.println("3.-  Cuenta Vista       ");
		System.out.println("4.-      Salir          ");
		
        respuestatipo = entrada.nextInt();
        
        if (respuestatipo==1 || respuestatipo==2 || respuestatipo==3 || respuestatipo==4) {
            
            switch (respuestatipo) {
            
            case 1 :
            	
            	this.tipocuenta[9][0]="Cuenta Corriente";
            	
            break;
            
            
            case 2 :
            	
            	this.tipocuenta[9][0]="Cuenta Ahorro";
            	
            break;
            
            case 3 :
            	
            	this.tipocuenta[9][0]="Cuenta Vista";
            	
            break;
            
            case 4 :
            	
            	salir();
            	
            break;
            
            }
            		
            }else {
            	System.out.println("Respuesta invalida");
            }
            	}
		
	//metodo para consultar el saldo de una cuenta por medio del rut
    public void consultasaldo() {
    	
    	if (validacliente==this.rutcliente[0][4]) {
    		System.out.println("Su saldo actual es: "+ this.saldo[0][5]);
    		menu3();
    	}
    	if (validacliente==this.rutcliente[1][4]) {
    		System.out.println("Su saldo actual es: "+ this.saldo[1][5]);
    		menu3();
    	}
	
    	if (validacliente==this.rutcliente[2][4]) {
    		System.out.println("Su saldo actual es: "+ this.saldo[2][5]);
    		menu3();
    	}
    	if (validacliente==this.rutcliente[3][4]) {
    		System.out.println("Su saldo actual es: "+ this.saldo[3][5]);
    		menu3();
    	}
    	if (validacliente==this.rutcliente[4][4]) {
    		System.out.println("Su saldo actual es: "+ this.saldo[4][5]);
    		menu3();
    	}
    	if (validacliente==this.rutcliente[5][4]) {
    		System.out.println("Su saldo actual es: "+ this.saldo[5][5]);
    		menu3();
    	}
    	if (validacliente==this.rutcliente[6][4]) {
    		System.out.println("Su saldo actual es: "+ this.saldo[6][5]);
    		menu3();
    	}
    	if (validacliente==this.rutcliente[7][4]) {
    		System.out.println("Su saldo actual es: "+ this.saldo[7][5]);
    		menu3();
    	}
    	if (validacliente==this.rutcliente[8][4]) {
    		System.out.println("Su saldo actual es: "+ this.saldo[8][5]);
    		menu3();
    	}
    	if (validacliente==this.rutcliente[9][4]) {
    		System.out.println("Su saldo actual es: "+ this.saldo[9][5]);
    		menu3();
    	}
    	
  }
	
    //metodo para ingresar dinero a una cuenta
	public void ingresar(double Saldo) {
		
		System.out.println("Cuanto dinero desea ingresar a su cuenta?");
		saldodeingreso = entrada.nextDouble();
		
		if(saldodeingreso<=0) {
			System.out.println("Solo se puede abonar con numeros positivos mayores que 0");
			menu3();
		}
		
		if (validacliente==this.rutcliente[0][4] && saldodeingreso>0) {
			
			this.saldo[0][5]=this.saldo[0][5]+saldodeingreso;
			System.out.println("Su nuevo saldo es de: "+this.saldo[0][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se Ingresaron: "+ saldodeingreso);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se Ingresaron: "+ saldodeingreso);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			menu3();
		}
		
        if (validacliente==this.rutcliente[1][4] && saldodeingreso>0) {
			
			this.saldo[1][5]=this.saldo[1][5]+saldodeingreso;
			System.out.println("Su nuevo saldo es de: "+this.saldo[1][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se Ingresaron: "+ saldodeingreso);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se Ingresaron: "+ saldodeingreso);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[2][4] && saldodeingreso>0) {
			
			this.saldo[2][5]=this.saldo[2][5]+saldodeingreso;
			System.out.println("Su nuevo saldo es de: "+this.saldo[2][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se Ingresaron: "+ saldodeingreso);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se Ingresaron: "+ saldodeingreso);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[3][4] && saldodeingreso>0) {
			
			this.saldo[3][5]=this.saldo[3][5]+saldodeingreso;
			System.out.println("Su nuevo saldo es de: "+this.saldo[3][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se Ingresaron: "+ saldodeingreso);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se Ingresaron: "+ saldodeingreso);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[4][4] && saldodeingreso>0) {
			
			this.saldo[4][5]=this.saldo[4][5]+saldodeingreso;
			System.out.println("Su nuevo saldo es de: "+this.saldo[4][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se Ingresaron: "+ saldodeingreso);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se Ingresaron: "+ saldodeingreso);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[5][4] && saldodeingreso>0) {
			
			this.saldo[5][5]=this.saldo[5][5]+saldodeingreso;
			System.out.println("Su nuevo saldo es de: "+this.saldo[5][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se Ingresaron: "+ saldodeingreso);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se Ingresaron: "+ saldodeingreso);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[6][4] && saldodeingreso>0) {
			
			this.saldo[6][5]=this.saldo[6][5]+saldodeingreso;
			System.out.println("Su nuevo saldo es de: "+this.saldo[6][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se Ingresaron: "+ saldodeingreso);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se Ingresaron: "+ saldodeingreso);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[7][4] && saldodeingreso>0) {
			
			this.saldo[7][5]=this.saldo[7][5]+saldodeingreso;
			System.out.println("Su nuevo saldo es de: "+this.saldo[7][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se Ingresaron: "+ saldodeingreso);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se Ingresaron: "+ saldodeingreso);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			menu3();
		}
        
       if (validacliente==this.rutcliente[8][4] && saldodeingreso>0) {
			
			this.saldo[8][5]=this.saldo[8][5]+saldodeingreso;
			System.out.println("Su nuevo saldo es de: "+this.saldo[8][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se Ingresaron: "+ saldodeingreso);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se Ingresaron: "+ saldodeingreso);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			menu3();
		}
       
       if (validacliente==this.rutcliente[9][4] && saldodeingreso>0) {
			
			this.saldo[9][5]=this.saldo[9][5]+saldodeingreso;
			System.out.println("Su nuevo saldo es de: "+this.saldo[9][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se Ingresaron: "+ saldodeingreso);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se Ingresaron: "+ saldodeingreso);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se Ingresaron: "+ saldodeingreso);
			
			}
			menu3();
		}
	}
	
	//metodo para retirar dinero a una cuenta
	public void retiro(double Saldo) {
		
		System.out.println("Cuanto dinero desea retirar de su cuenta?");
		saldoretiro = entrada.nextDouble();
		
		
		
		if (validacliente==this.rutcliente[0][4] && saldoretiro<=this.saldo[0][5]) {
			
			this.saldo[0][5]=(this.saldo[0][5]-saldoretiro);
			System.out.println("Retiro exitoso");
			System.out.println("Su nuevo saldo es de: "+this.saldo[0][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se retiraron :"+ saldoretiro);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se retiraron :"+ saldoretiro);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se retiraron :"+ saldoretiro);
			
			}
			menu3();
		}
		
        if (validacliente==this.rutcliente[1][4] && saldoretiro<=this.saldo[1][5]) {
			
			this.saldo[1][5]=(this.saldo[1][5]-saldoretiro);
			System.out.println("Retiro exitoso");
			System.out.println("Su nuevo saldo es de: "+this.saldo[1][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se retiraron :"+ saldoretiro);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se retiraron :"+ saldoretiro);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se retiraron :"+ saldoretiro);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[2][4] && saldoretiro<=this.saldo[2][5]) {
			
			this.saldo[2][5]=(this.saldo[2][5]-saldoretiro);
			System.out.println("Retiro exitoso");
			System.out.println("Su nuevo saldo es de: "+this.saldo[2][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se retiraron :"+ saldoretiro);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se retiraron :"+ saldoretiro);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se retiraron :"+ saldoretiro);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[3][4] && saldoretiro<=this.saldo[3][5]) {
			
			this.saldo[3][5]=(this.saldo[3][5]-saldoretiro);
			System.out.println("Retiro exitoso");
			System.out.println("Su nuevo saldo es de: "+this.saldo[3][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se retiraron :"+ saldoretiro);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se retiraron :"+ saldoretiro);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se retiraron :"+ saldoretiro);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[4][4] && saldoretiro<=this.saldo[4][5]) {
			
			this.saldo[4][5]=(this.saldo[4][5]-saldoretiro);
			System.out.println("Retiro exitoso");
			System.out.println("Su nuevo saldo es de: "+this.saldo[4][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se retiraron :"+ saldoretiro);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se retiraron :"+ saldoretiro);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se retiraron :"+ saldoretiro);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[5][4] && saldoretiro<=this.saldo[5][5]) {
			
			this.saldo[5][5]=(this.saldo[5][5]-saldoretiro);
			System.out.println("Retiro exitoso");
			System.out.println("Su nuevo saldo es de: "+this.saldo[5][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se retiraron :"+ saldoretiro);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se retiraron :"+ saldoretiro);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se retiraron :"+ saldoretiro);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[6][4] && saldoretiro<=this.saldo[6][5]) {
			
			this.saldo[6][5]=(this.saldo[6][5]-saldoretiro);
			System.out.println("Retiro exitoso");
			System.out.println("Su nuevo saldo es de: "+this.saldo[6][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se retiraron :"+ saldoretiro);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se retiraron :"+ saldoretiro);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se retiraron :"+ saldoretiro);
			
			}
			menu3();
		}
        if (validacliente==this.rutcliente[7][4] && saldoretiro<=this.saldo[7][5]) {
			
			this.saldo[7][5]=(this.saldo[7][5]-saldoretiro);
			System.out.println("Retiro exitoso");
			System.out.println("Su nuevo saldo es de: "+this.saldo[7][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se retiraron :"+ saldoretiro);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se retiraron :"+ saldoretiro);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se retiraron :"+ saldoretiro);
			
			}
			menu3();
		
}
       if (validacliente==this.rutcliente[8][4] && saldoretiro<=this.saldo[8][5]) {
			
			this.saldo[8][5]=(this.saldo[8][5]-saldoretiro);
			System.out.println("Retiro exitoso");
			System.out.println("Su nuevo saldo es de: "+this.saldo[8][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se retiraron :"+ saldoretiro);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se retiraron :"+ saldoretiro);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se retiraron :"+ saldoretiro);
			
			}
			menu3();
		}
       
       if (validacliente==this.rutcliente[9][4] && saldoretiro<=this.saldo[9][5]) {
			
			this.saldo[9][5]=(this.saldo[9][5]-saldoretiro);
			System.out.println("Retiro exitoso");
			System.out.println("Su nuevo saldo es de: "+this.saldo[9][5]);
			if(movimientos[0][0]==null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][0]=("Se retiraron :"+ saldoretiro);
			}
			
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][1]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]==null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][2]=("Se retiraron :"+ saldoretiro);
			
			}
			if(movimientos[0][0]!=null && movimientos[0][1]!=null && movimientos[0][2]!=null && movimientos[0][3]==null && movimientos[0][4]==null){
				movimientos[0][3]=("Se retiraron :"+ saldoretiro);	
			}
			if(movimientos[0][0]!=null && movimientos[0][1]==null && movimientos[0][2]==null && movimientos[0][3]!=null && movimientos[0][4]==null){
				movimientos[0][4]=("Se retiraron :"+ saldoretiro);
			
			}
			menu3();
		}
	}
	
	//metodo para validar rut Chileno
	public boolean validarutchileno(boolean validacion) {
		
		rut = null;
		
		validacion = false;
		
		try {
		rut =  rut.toUpperCase();
		rut = rut.replace(".", "");
		rut = rut.replace("-", "");
		int rutAux = Integer.parseInt(rut.substring(0, rut.length() - 1));

		char dv = rut.charAt(rut.length() - 1);

		int m = 0, s = 1;
		for (; rutAux != 0; rutAux /= 10) {
		s = (s + rutAux % 10 * (9 - m++ % 6)) % 11;
		}
		if (dv == (char) (s != 0 ? s + 47 : 75)) {
		validacion = true;
		}

		} catch (java.lang.NumberFormatException e) {
		} catch (Exception e) {
		}
		return validacion;
		}
	
	//metodo para cambiar clave
	public void cambioclave() {
		
		System.out.println("Ingrese su clave actual");
		clavecambio = entrada.nextInt();
		
		if(clavecambio==this.clave[0][6] && validacliente==this.rutcliente[0][4]) {
			System.out.println("Ingrese su nueva clave");
			nuevaclave = entrada.nextInt();
			this.clave[0][6]=nuevaclave;		
		}
		if(clavecambio==this.clave[1][6] && validacliente==this.rutcliente[1][4]) {
			System.out.println("Ingrese su nueva clave");
			nuevaclave = entrada.nextInt();
			this.clave[1][6]=nuevaclave;		
		}
		if(clavecambio==this.clave[2][6] && validacliente==this.rutcliente[2][4]) {
			System.out.println("Ingrese su nueva clave");
			nuevaclave = entrada.nextInt();
			this.clave[2][6]=nuevaclave;		
		}
		if(clavecambio==this.clave[3][6] && validacliente==this.rutcliente[3][4]) {
			System.out.println("Ingrese su nueva clave");
			nuevaclave = entrada.nextInt();
			this.clave[3][6]=nuevaclave;		
			}
		if(clavecambio==this.clave[4][6] && validacliente==this.rutcliente[4][4]) {
			System.out.println("Ingrese su nueva clave");
			nuevaclave = entrada.nextInt();
			this.clave[4][6]=nuevaclave;		
			}
		if(clavecambio==this.clave[5][6] && validacliente==this.rutcliente[5][4]) {
			System.out.println("Ingrese su nueva clave");
			nuevaclave = entrada.nextInt();
			this.clave[5][6]=nuevaclave;		
			}
		if(clavecambio==this.clave[6][6] && validacliente==this.rutcliente[6][4]) {
			System.out.println("Ingrese su nueva clave");
			nuevaclave = entrada.nextInt();
			this.clave[6][6]=nuevaclave;		
			}
		if(clavecambio==this.clave[7][6] && validacliente==this.rutcliente[7][4]) {
			System.out.println("Ingrese su nueva clave");
			nuevaclave = entrada.nextInt();
			this.clave[7][6]=nuevaclave;		
			}
		if(clavecambio==this.clave[8][6] && validacliente==this.rutcliente[8][4]) {
			System.out.println("Ingrese su nueva clave");
			nuevaclave = entrada.nextInt();
			this.clave[8][6]=nuevaclave;		
			}
		if(clavecambio==this.clave[9][6] && validacliente==this.rutcliente[9][4]) {
			System.out.println("Ingrese su nueva clave");
			nuevaclave = entrada.nextInt();
			this.clave[9][6]=nuevaclave;		
			}
	}
	
	//metodo para validar la id y clave para acceder a privilegios de administrador
	public boolean validaradministrador(boolean validaradmin) {
		
	
		
		 System.out.println("Ingrese nombre de usuario:");
    	 String nadmin = entrada.next();
    	 System.out.println("Ingrese clave de usuario:");
    	 String cadmin = entrada.next();
    	 
    	 
    	 
    	 if(nadmin.equals("root") && cadmin.equals("root")) {
    		 System.out.println("Login de administrador exitoso");
    		 this.validaradmin=true;
    	 }
    	 
    	 else {
    		 System.out.println("usuario y contrase�a incorrectos");
    		 this.validaradmin=false;
    	 }
    		return validaradmin;
	}
	
	// este metodo contiene el primer menu donde se pregunta si el usuario es administrador o cliente
	public void menu1() {
		
		int res1=0;
		
		while(res1!=3) {
		
		System.out.println("*******************************");
		System.out.println("**Bienbenido al banco aweklab**");
		System.out.println("*******************************");
		System.out.println("**Seleccionar tipo de usuario**");
		System.out.println("*******************************");
		System.out.println("*******1.-Administrador********");
		System.out.println("*******************************");
		System.out.println("*******2.-   Cliente   ********");
		System.out.println("*******************************");
		System.out.println("*******3.-    Salir    ********");
		System.out.println("*******************************");
		
		 res1 = entrada.nextInt();
		 
		  if (res1==1 || res1==2 || res1==3) {
			  
			  
			  switch (res1) {
	           
		         case 1 :
		        	 
		        	 validaradministrador(validaradmin);
		        	 
		        	
		        	 
		        	  if(validaradmin==true) {
		        		 		 
	        	         	menu2(); 
		        		 
		        	 }if(validaradmin==false) {
		        		
		        		    menu1();
		        	 }
		      	 
		        	 
			      break;
			     
		         case 2 :
		        	 
		        	 validarcliente(validarutcliente);
		        	 
		        	 if(validarutcliente==true) {
        		 		 
	        	         	menu3(); 
		        		 
		        	 }if(validarutcliente==false) {
		        		
		        		    menu1();
		        	 }
		      	 
		        	 
		         break;
		         
                 case 3 :
		        	 
		        	 salir();
		        	 
		         break;
		         
			  
		  }	
			  }	else {
				  System.out.println("Respuesta incorrecta intentelo de nuevo");
			  
		  }
			  
	
	}
		
		}
	
	//metodo que contiene el menu del administrador donde puede crear una cuenta, crear cliente y mostrar cliente 
	public void menu2() {
		
		int res2=0;
		
		while(res2!=4) {
		
		    System.out.println("******************************************");
			System.out.println("********Bienbenido al banco aweklab*******");
			System.out.println("******************************************");
			System.out.println("**Seleccionar la opcion de administrador**");
			System.out.println("******************************************");
			System.out.println("*******      1.-Crear cuenta    **********");
			System.out.println("******************************************");
			System.out.println("*******      2.-Crear Cliente   **********");
			System.out.println("******************************************");
			System.out.println("*******      3.-Mostrar Cliente  *********");
			System.out.println("******************************************");
			System.out.println("*******      4.-    Salir        *********");
			System.out.println("******************************************");
		
			 res2 = entrada.nextInt();
			 
			 switch (res2) {
	           
	         case 1 :
	        	
	        		 crearcuenta(null);
	        	 
	        	 
		      break;
		     
	          case 2 :
	        	 
	        	    crearcliente();
	        	 
 	          break;
	         
              case 3 :
	        	 
	        	    mostrarcliente();
	        	 
	          break;
	          
              case 4 :
 	        	 
	        	   salir();
	        	 
	          break;
			
			 }
		}
	}
	
	//metodo que contiene el menu del cliente donde puede: abonar dinero, retirar dinero, consultar dinero, cambio clave, ver los ultimos movimientos
	public void menu3() {

		
        int res3=0;
		
		while(res3!=6) {
		
	    System.out.println("******************************************");
		System.out.println("********Bienbenido al banco aweklab*******");
		System.out.println("******************************************");
		System.out.println("***  Seleccionar la opcion de Cliente  ***");
		System.out.println("******************************************");
		System.out.println("******* 1.-     Abono dinero    **********");
		System.out.println("******************************************");
		System.out.println("******* 2.-     retirar dinero  **********");
		System.out.println("******************************************");
		System.out.println("******* 3.-     consultar saldo **********");
		System.out.println("******************************************");
		System.out.println("******* 4.-     cambiar clave       ******");
		System.out.println("******************************************");
		System.out.println("******* 5.- ver ultimos movimientos*******");
		System.out.println("******************************************");
		System.out.println("******* 6.-        salir           *******");
		System.out.println("******************************************");
		
		res3 = entrada.nextInt();
		
		 switch (res3) {
         
         case 1 :
        	
        		ingresar(saldodeingreso);
            	 
        	 
	      break;
	      
         case 2 :
         	
     		
             	retiro(saldoretiro);
     	 
     	 
	      break;
	      
         case 3 :
          	
      		
          	 consultasaldo();
     	 
     	 
	      break;
	      
         case 4 :
          	
      		
          	cambioclave();
     	 
     	 
	      break;
	      
         case 5 :
           	
       		
          	 ultimosmovimientos();
     	 
     	 
	      break;
	      
         case 6 :
            	
        		
          	 salir();
     	     menu1();
     	 
	      break;
	      
	     
		
		 }
		}
			
	}
	
	//metodo para crear clientes
	public void crearcliente() {
		
        cliente c1 = new cliente(apellidocliente, numcuenta, apellidocliente, apellidocliente, numcuenta, saldo, clave);
		
		System.out.println("Ingrese rut del cliente");
		
		c1.rutcliente[0][2]= entrada.nextInt();
		
	    if(c1.rutcliente[0][2]==this.rutcliente[5][4] || c1.rutcliente[0][2]==this.rutcliente[6][4] || c1.rutcliente[0][2]==this.rutcliente[7][4] || c1.rutcliente[0][2]==this.rutcliente[8][4] || c1.rutcliente[0][2]==this.rutcliente[9][4]) {
		
		System.out.println("Este cliente ya dispone de una cuenta en nuestro sistema");
		
		menu2();
		
	}
		
	System.out.println("Ingrese Nombre del cliente");
	
	c1.nombrecliente[0][0]= entrada.next();
	
    System.out.println("Ingrese apellido del cliente");
	
	c1.apellidocliente[0][1]= entrada.next();
	
	
	
		
	}
	
	//metodo para validar clientes por medio de rut y clave
	public boolean validarcliente(boolean validarutcliente) {
		
		System.out.println("Ingrese Su rut");
		validacliente = entrada.nextInt(); 
		System.out.println("Ingrese su clave");
		clavecliente = entrada.nextInt();
		
		
		
		if (validacliente==this.rutcliente[0][4] && clavecliente==this.clave[0][6] || validacliente==this.rutcliente[1][4] && clavecliente==this.clave[1][6] || validacliente==this.rutcliente[2][4] && clavecliente==this.clave[2][6] || validacliente==this.rutcliente[3][4] && clavecliente==this.clave[3][6] || validacliente==this.rutcliente[4][4] && clavecliente==this.clave[4][6] || validacliente==this.rutcliente[5][4] && clavecliente==this.clave[5][6]|| validacliente==this.rutcliente[6][4] && clavecliente==this.clave[6][6] || validacliente==this.rutcliente[7][4] && clavecliente==this.clave[7][6] || validacliente==this.rutcliente[8][4] && clavecliente==this.clave[8][6] ||validacliente==this.rutcliente[9][4] && clavecliente==this.clave[9][6] ) {
		
			this.validarutcliente=true;
		}else {
			System.out.println("Este rut no se encuentra registrado en nuestro banco");
			this.validarutcliente=false;
			menu1();
		}
		
		return validarutcliente;
		
	}
	
	//metodo para mostrar la informacion del cliente
	public void mostrarcliente() {
		
		System.out.println("Cliente 1: " +"tipo de cuenta: "+this.tipocuenta[0][0]+" Numero de cuenta: "+this.numcuenta[0][1]+" Nombre del Cliente: "+this.nombrecliente[0][2]+" Apellido del cliente: "+this.apellidocliente[0][3]+" Rut del cliente: "+this.rutcliente[0][4]+" Saldo actual del cliente: "+this.saldo[0][5]);
		System.out.println("Cliente 2: " +"tipo de cuenta: "+this.tipocuenta[1][0]+" Numero de cuenta: "+this.numcuenta[1][1]+" Nombre del Cliente: "+this.nombrecliente[1][2]+" Apellido del cliente: "+this.apellidocliente[1][3]+" Rut del cliente: "+this.rutcliente[1][4]+" Saldo actual del cliente: "+this.saldo[1][5]);
		System.out.println("Cliente 3: " +"tipo de cuenta: "+this.tipocuenta[2][0]+" Numero de cuenta: "+this.numcuenta[2][1]+" Nombre del Cliente: "+this.nombrecliente[2][2]+" Apellido del cliente: "+this.apellidocliente[2][3]+" Rut del cliente: "+this.rutcliente[2][4]+" Saldo actual del cliente: "+this.saldo[2][5]);
		System.out.println("Cliente 4: " +"tipo de cuenta: "+this.tipocuenta[3][0]+" Numero de cuenta: "+this.numcuenta[3][1]+" Nombre del Cliente: "+this.nombrecliente[3][2]+" Apellido del cliente: "+this.apellidocliente[3][3]+" Rut del cliente: "+this.rutcliente[3][4]+" Saldo actual del cliente: "+this.saldo[3][5]);
		System.out.println("Cliente 5: " +"tipo de cuenta: "+this.tipocuenta[4][0]+" Numero de cuenta: "+this.numcuenta[4][1]+" Nombre del Cliente: "+this.nombrecliente[4][2]+" Apellido del cliente: "+this.apellidocliente[4][3]+" Rut del cliente: "+this.rutcliente[4][4]+" Saldo actual del cliente: "+this.saldo[4][5]);
		System.out.println("Cliente 6: " +"tipo de cuenta: "+this.tipocuenta[5][0]+" Numero de cuenta: "+this.numcuenta[5][1]+" Nombre del Cliente: "+this.nombrecliente[5][2]+" Apellido del cliente: "+this.apellidocliente[5][3]+" Rut del cliente: "+this.rutcliente[5][4]+" Saldo actual del cliente: "+this.saldo[5][5]);
		System.out.println("Cliente 7: " +"tipo de cuenta: "+this.tipocuenta[6][0]+" Numero de cuenta: "+this.numcuenta[6][1]+" Nombre del Cliente: "+this.nombrecliente[6][2]+" Apellido del cliente: "+this.apellidocliente[6][3]+" Rut del cliente: "+this.rutcliente[6][4]+" Saldo actual del cliente: "+this.saldo[6][5]);
		System.out.println("Cliente 8: " +"tipo de cuenta: "+this.tipocuenta[7][0]+" Numero de cuenta: "+this.numcuenta[7][1]+" Nombre del Cliente: "+this.nombrecliente[7][2]+" Apellido del cliente: "+this.apellidocliente[7][3]+" Rut del cliente: "+this.rutcliente[7][4]+" Saldo actual del cliente: "+this.saldo[7][5]);
		System.out.println("Cliente 9: " +"tipo de cuenta: "+this.tipocuenta[8][0]+" Numero de cuenta: "+this.numcuenta[8][1]+" Nombre del Cliente: "+this.nombrecliente[8][2]+" Apellido del cliente: "+this.apellidocliente[8][3]+" Rut del cliente: "+this.rutcliente[8][4]+" Saldo actual del cliente: "+this.saldo[8][5]);
		System.out.println("Cliente 10: " +"tipo de cuenta: "+this.tipocuenta[9][0]+" Numero de cuenta: "+this.numcuenta[9][1]+" Nombre del Cliente: "+this.nombrecliente[9][2]+" Apellido del cliente: "+this.apellidocliente[9][3]+" Rut del cliente: "+this.rutcliente[9][4]+" Saldo actual del cliente: "+this.saldo[9][5]);

		
		
	}
	
	public void ultimosmovimientos() {
		
		if (clavecliente==this.clave[0][6] && validacliente==this.rutcliente[0][4]) {
			
			System.out.println("Los ultimos 5 movimientos de su cuenta son: "+movimientos[0][0]+" "+movimientos[0][1]+" "+movimientos[0][2]+" "+movimientos[0][3]+" "+movimientos[0][4]);
			menu3();
		}
        if (clavecliente==this.clave[1][6] && validacliente==this.rutcliente[1][4]) {
			
        	System.out.println("Los ultimos 5 movimientos de su cuenta son: "+movimientos[0][0]+" "+movimientos[0][1]+" "+movimientos[0][2]+" "+movimientos[0][3]+" "+movimientos[0][4]);
			menu3();
		}
        if (clavecliente==this.clave[2][6] && validacliente==this.rutcliente[2][4]) {
			
        	System.out.println("Los ultimos 5 movimientos de su cuenta son: "+movimientos[0][0]+" "+movimientos[0][1]+" "+movimientos[0][2]+" "+movimientos[0][3]+" "+movimientos[0][4]);
			menu3();
		}
        if (clavecliente==this.clave[3][6] && validacliente==this.rutcliente[3][4]) {
			
        	System.out.println("Los ultimos 5 movimientos de su cuenta son: "+movimientos[0][0]+" "+movimientos[0][1]+" "+movimientos[0][2]+" "+movimientos[0][3]+" "+movimientos[0][4]);
			menu3();
		}
        if (clavecliente==this.clave[4][6] && validacliente==this.rutcliente[4][4]) {
			
        	System.out.println("Los ultimos 5 movimientos de su cuenta son: "+movimientos[0][0]+" "+movimientos[0][1]+" "+movimientos[0][2]+" "+movimientos[0][3]+" "+movimientos[0][4]);
			menu3();
		}
        if (clavecliente==this.clave[5][6] && validacliente==this.rutcliente[5][4]) {
			
        	System.out.println("Los ultimos 5 movimientos de su cuenta son: "+movimientos[0][0]+" "+movimientos[0][1]+" "+movimientos[0][2]+" "+movimientos[0][3]+" "+movimientos[0][4]);
			menu3();
		}
        if (clavecliente==this.clave[6][6] && validacliente==this.rutcliente[6][4]) {
			
        	System.out.println("Los ultimos 5 movimientos de su cuenta son: "+movimientos[0][0]+" "+movimientos[0][1]+" "+movimientos[0][2]+" "+movimientos[0][3]+" "+movimientos[0][4]);
			menu3();
		}
        if (clavecliente==this.clave[7][6] && validacliente==this.rutcliente[7][4]) {
			
        	System.out.println("Los ultimos 5 movimientos de su cuenta son: "+movimientos[0][0]+" "+movimientos[0][1]+" "+movimientos[0][2]+" "+movimientos[0][3]+" "+movimientos[0][4]);
			menu3();
		}
        if (clavecliente==this.clave[8][6] && validacliente==this.rutcliente[8][4]) {
	
        	System.out.println("Los ultimos 5 movimientos de su cuenta son: "+movimientos[0][0]+" "+movimientos[0][1]+" "+movimientos[0][2]+" "+movimientos[0][3]+" "+movimientos[0][4]);
	        menu3();
        }
        if (clavecliente==this.clave[9][6] && validacliente==this.rutcliente[9][4]) {
	
        	System.out.println("Los ultimos 5 movimientos de su cuenta son: "+movimientos[0][0]+" "+movimientos[0][1]+" "+movimientos[0][2]+" "+movimientos[0][3]+" "+movimientos[0][4]);
	        menu3();
}
	}
	
	//metodo utilizado en varios metodos para salir
    public void salir() {
		
    	System.out.println("   _______       __ __                __           ");
    	System.out.println("  |   _   .---.-|  |__.-----.-----.--|  .-----.    ");
 		System.out.println("  |   1___|  _  |  |  |  -__|     |  _  |  _  |    ");
 		System.out.println("  |____   |___._|__|__|_____|__|__|_____|_____|    ");
 		System.out.println("  |:  1   |                                        ");
 	    System.out.println("  |::.. . |                                        ");
 	    System.out.println("  `-------'                                        ");
 	    
	}
}
	
