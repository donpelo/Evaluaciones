package Prueba1ejercicio3;

public class Automovil {
	
	String marca;
	String modelo;
	int a�o;
	double precio;
	double preciofinal;
	
	
	

	public Automovil(String marca, String modelo, int a�o, double precio, double preciofinal) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.a�o = a�o;
		this.precio = precio;
		this.preciofinal = preciofinal;
	}


	

	public String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}


	public String getModelo() {
		return modelo;
	}


	public void setModelo(String modelo) {
		this.modelo = modelo;
	}


	public int getA�o() {
		return a�o;
	}


	public void setA�o(int a�o) {
		this.a�o = a�o;
	}


	public double getPrecio() {
		return precio;
	}


	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	public double getPreciofinal() {
		return preciofinal;
	}


	public void setPreciofinal(double preciofinal) {
		this.preciofinal = (precio+(0.19*precio)+(0.5*precio)+100000);
	}

	
	

}
