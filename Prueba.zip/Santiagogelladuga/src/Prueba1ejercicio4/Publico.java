package Prueba1ejercicio4;

public class Publico extends Empleado {
	
	int rut;
	String nombre;
	String apellidos;
	String direccion;
	int telefono;
	double sueldo;
	String municipalidad;
	String departamento;
	
	
	Publico(int rut, String nombre, String apellidos, String direccion, int telefono, double sueldo,
			String municipalidad, String departamento) {
		super(rut, nombre, apellidos, direccion, telefono, sueldo, municipalidad,departamento);
		this.rut= rut;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.direccion = direccion;
		this.telefono = telefono;
		this.sueldo = sueldo;
		this.municipalidad = municipalidad;
		this.departamento = departamento;
	}
	

	}
	
	
	
	
	


