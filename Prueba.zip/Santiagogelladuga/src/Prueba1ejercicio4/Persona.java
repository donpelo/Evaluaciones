package Prueba1ejercicio4;

public class Persona {
	
	public static void main(String[] args) {
	
		Publico epublico = new Publico(152423566, "Fernando", "Mellado Salinas", "Los laureles 45",945281947, 780000, "Municipalidad de los alamos", "Administrativo");
        Privado eprivado = new Privado(123456787, "Francisco", "Risopatron de Lourdes", "Juan bosco 1786", 976834616, 6000000, "Comuna Las condes", "Gerencia");
        
        System.out.println("Rut: "+epublico.getRut()+", "+" Nombre: "+epublico.getNombre()+", "+" Apellidos: "+epublico.getApellidos()+", "+" Direccion: "+epublico.getDireccion()+", "+" Telefono: "+epublico.getTelefono()+", "+" Sueldo: "+epublico.getSueldo()+", "+" Municipalidad: "+epublico.municipalidad+", "+" Departamento: "+epublico.departamento);
        System.out.println("Rut: "+eprivado.getRut()+", "+" Nombre: "+eprivado.getNombre()+", "+" Apellidos: "+eprivado.getApellidos()+", "+" Direccion: "+eprivado.getDireccion()+", "+" Telefono: "+eprivado.getTelefono()+", "+" Sueldo: "+eprivado.getSueldo()+", "+" Comuna: "+eprivado.comuna+", "+" Empresa: "+eprivado.empresa);
}
}