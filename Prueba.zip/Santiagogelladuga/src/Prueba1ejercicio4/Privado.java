package Prueba1ejercicio4;

public class Privado extends Empleado {
	
	int rut;
	String nombre;
	String apellidos;
	String direccion;
	int telefono;
	double sueldo;
	String comuna;
	String empresa;
	
	public Privado(int rut, String nombre, String apellidos, String direccion, int telefono, double sueldo,
			String comuna, String empresa) {
		super(rut, nombre, apellidos, direccion, telefono, sueldo,comuna,empresa);
		this.rut = rut;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.direccion = direccion;
		this.telefono = telefono;
		this.sueldo = sueldo;
		this.comuna = comuna;
		this.empresa = empresa;
	}

	public int getRut() {
		return rut;
	}

	public void setRut(int rut) {
		this.rut = rut;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public int getTelefono() {
		return telefono;
	}
	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}
	public double getSueldo() {
		return sueldo;
	}
	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}
	public String getComuna() {
		return comuna;
	}
	public void setComuna(String comuna) {
		this.comuna = comuna;
	}
	public String getEmpresa() {
		return empresa;
	}
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	
}
